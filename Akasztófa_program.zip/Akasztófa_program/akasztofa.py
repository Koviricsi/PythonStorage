import random


#Változók/listák (Ricsi)


szinek = ["\033[0;31m", "\033[0;33m", "\033[0;36m", "\033[0;32m", "\033[0;35m"] #Piros, sárga, kék, zöld, lila
tiszta = "\033c"
eletek = 12
rossz_tippek = []
jo_tippek = []
rossz_szavak = []


#Általunk megadott szavak (témakörök)


temakorok = [["kutya", "macska", "tigris", "elefánt", "sas", "pingvin", "hattyú", "kígyó", "pók", "hangya", "delfin", "jegesmedve", "szarvas", "mókus"],
             ["akácfa", "ibolya", "szegfűszeg", "pálmafa", "rozmaring", "uborka", "sárgarépa", "cseresznyevirág", "jácintfa", "saláta"],
             ["szék", "asztal", "kanapé", "ágy", "ruhásszekrény", "falipolc", "tükör", "párna", "szőnyeg"],
             ["pizza", "hamburger", "tészta", "tea", "kávé", "csokoládé", "torta", "fagylalt", "paradicsomleves", "sushi", "omlett"],
             ["személyautó", "teherautó", "motor", "repülő", "helikopter", "siklóernyő", "hajó", "óceánjáró", "kenu"]]
            #1. állatok, 2. növények, 3. bútorok, 4. ételek/italok, 5. közlekedési eszközök
            
nehezseg = 0
temakor = ""
szo = ""
megoldas = ""
tipp = ""


    #->Fájlbeolvasás


x = open(r"szabalyzat.txt", encoding="utf-8") #Játék szabályok

szabalyzat = x.read()   

x = open(r"magyar-szavak.txt", encoding="utf-8")  #Összes magyar szó 

szavak = []

for szo in x:
    szavak.append(szo.replace("\n", ""))
    
    
  #Ábrák    
    
    
x = open(r"abrak.txt", encoding="utf-8")

abrak = [] #12db ábra

sorok = x.readlines()


for i in range(1, 169+1, 13):   #Ábrák bolvasása (13 sor/1 ábra)
    ideiglenes = ""
    abra = sorok[i-1:i+12]
    
    for j in abra:
        ideiglenes += j
        
    abrak.append(ideiglenes)
    
    
#Ábrák a játék végéhez
    
    
x = open(r"vege.txt", encoding="utf-8") 

abrak_vege = [] #2db ábra

sorok = x.readlines()

for i in range(1, 16+1, 8): #Ábrák beolvasása (8 sor/1 ábra)
    ideiglenes = ""
    abra = sorok[i-1:i+7]
    
    for j in abra:
        ideiglenes += j
        
    abrak_vege.append(ideiglenes)

x.close()


#Függvények (Ádám & Ricsi)
#Nehézség választás, témaválasztás, szó sorsolás, tipp bekérés, győzelem, vereség


    #Játék nehézségének kiválasztása


def nehezseg_valasztas():
    print(tiszta)
    while True:
        try:
            nehezseg = int(input(szinek[3-1] + "Milyen nehézségi fokon szeretne játszani? (A nehézség sorszámát írja le)\n" 
                                + szinek[4-1] + "[1] - Könnyű: kiválaszthatja milyen témakörhöz tartozó szavakkal szeretne játszani (kb.10-20szó)\n"
                                + szinek[2-1] + "[2] - Normál: a témakörök bármelyikéből kaphat szót (kb.100-200 szó)\n"
                                + szinek[1-1] + "[3] - Nehéz: az ÖSSZES magyar szóval fog játszani beleértve az ÖSSZES NYELVTANI SZÓFAJT! (kb.160k+ szó)\n" + szinek[5-1]))
            
            if nehezseg < 1 or nehezseg > 3:
                print(tiszta + szinek[2-1] + "Nem megfelelő értéket adott meg!")
            else:
                return nehezseg
            
        except:
            print(tiszta + szinek[2-1] + "Nem megfelelő értéket adott meg!")
    
    
    #Témakör kiválasztás


def tema_valasztas():
    global temakor
    print(tiszta)
    
    while True:
        try:
            tema = int(input(szinek[3-1] + "Melyik témakörhöz kapcsolódó szavakkal szeretne játszani? (A témakör sorszámát írja le)\n" + szinek[2-1]
                            + "[1] - Állatok\n"
                            + "[2] - Növények\n"
                            + "[3] - Bútorok és háztartási tárgyak\n"
                            + "[4] - Ételek és italok\n"
                            + "[5] - Közlekedési eszközök\n" + szinek[5-1]))
            
            if tema < 1 or tema > 5:
                print(tiszta + szinek[2-1] + "Nem megfelelő értéket adott meg!")
                
            else:
                if tema == 1:
                    temakor = "Állatok"
                    
                elif tema == 2:
                    temakor = "Növények"
                    
                elif tema == 3:
                    temakor = "Bútorok és háztartási tárgyak"
                    
                elif tema == 4:
                    temakor = "Ételek és italok"
                    
                elif tema == 5:
                    temakor = "Közlekedési eszközök"
                return tema
            
        except:
            print(tiszta + szinek[2-1] + "Nem megfelelő értéket adott meg!")


    #Random szó sorsolás


def szo_sorsolas():
    global nehezseg
    nehezseg = nehezseg_valasztas()
    
    if nehezseg == 1:
        rszo = random.choice(temakorok[tema_valasztas()-1])
        
    elif nehezseg == 2:
        rszo = random.choice(random.choice(temakorok))
        
    else:
        rszo = random.choice(szavak)
        
    return rszo


    #Tipp bekérés (karakter vagy szó tippelése)


def tipp_bekeres():
    while True:
        try:
            tipp = input(szinek[3-1] + "Tippeljen egy karaktert vagy egy konkrét szót! Ne használjon nagybetűt egy karakter tippelésekor!\nÍrjon be \"1\"-t a játék működésének megtekintéséhez.\n" + szinek[5-1])
            
            if ((len(tipp) == 1) or (tipp in szavak)) and (not tipp in rossz_tippek) and (not tipp in jo_tippek) and (not tipp in rossz_szavak) and (tipp.isalpha()) and (tipp.islower()):
                return tipp
            
            elif (tipp in rossz_tippek) or (tipp in jo_tippek):
                print(szinek[2-1] + "Az adott karaktert már megtippelte egyszer.")
                
            elif (tipp in rossz_szavak):
                print(szinek[2-1] + "Az adott szót már megtippelte egyszer.")
                
            elif tipp == "1":
                print(szinek[5-1] + "\n" + szabalyzat + "\n")
            
            else:
                print(szinek[2-1] + "Nem megfelelő karaktert/szót adott meg! Figyeljen a kis- és nagybetűkre!")
                
        except:
            print(tiszta + szinek[2-1] + "Nem megfelelő értéket adott meg!")


    #Tipp ellenőrzés (rossz tipp esetén -1 élet)


def tipp_ellenorzes():
    global eletek, megoldas
    ideiglenes = megoldas
    
    if len(tipp) == 1:
        for i in range(len(szo)):
            if szo[i] == tipp:
                megoldas = megoldas[:i] + tipp + megoldas[i+1:]
                
        if ideiglenes == megoldas:
            rossz_tippek.append(tipp)
            eletek -= 1
            return
        
        else:
            jo_tippek.append(tipp)
            return
        
    else:
        if tipp == szo:
            megoldas = szo
            return
        
        else:
            rossz_szavak.append(tipp)
            eletek -= 1
            return
        
        
    #Játék végén győzelem  
        
        
def gyozelem():
    print(tiszta)
    print(szinek[2-1] + abrak[12-eletek])
    print(szinek[4-1] + abrak_vege[0])
    print(szinek[3-1] + f"A szó a(z) \"{szo}\" volt.")
    return ujrakezdes()
        
            
    #Játék végén vereség            
         
            
def vereseg():
    print(tiszta)
    print(szinek[2-1] + abrak[12-eletek])
    print(szinek[1-1] + abrak_vege[1])
    print(szinek[3-1] + f"A szó a(z) \"{szo}\" volt.")
    return ujrakezdes()


    #Játék újraindítása


def ujrakezdes():
    while True:
        try:
            ujra = input(szinek[3-1] + "Szeretné újrakezdeni a játékot? (igen/nem) " + szinek[5-1])
                
            if ujra == "igen":
                return True
            elif ujra == "nem":
                return False
            else:
                print(tiszta + szinek[2-1] + "Nem megfelelő választ adott meg!")
        except:
            print(tiszta + szinek[2-1] + "Nem megfelelő értéket adott meg!")



#Kezdőszó sorsolás (Ádám)


szo = szo_sorsolas()
megoldas = len(szo) * "_"
print(tiszta)



#A játék főciklusa (Ádám & Ricsi)


while True:
    
    
    #Adatok és ábra kiírása terminálra (Ádám & Ricsi)
    
    
    print(szinek[2-1] + abrak[12-eletek])
    
    if nehezseg == 1:
        print(szinek[3-1] + f"Kiválasztott témakör: {temakor}")
        
    print(szinek[5-1] + f"Életeid: {eletek}\n"
          + szinek[1-1] + f"Eddigi rossz karakter tippjeid: " + ", ".join(rossz_tippek) + "\n"
                        + f"Eddig rossz szó tippjeid: " + ", ".join(rossz_szavak) + "\n"
          + szinek[4-1] + f"Eddigi jó karakter tippjeid: " + ", ".join(jo_tippek) + "\n"
          + szinek [3-1] + f"Jelenlegi állás: {megoldas}")
    
    
    #Tipp bekérés
    
    
    tipp = tipp_bekeres()
    print(tiszta)
    
    
    #Tipp ellenőrzése (jó/rossz)
    
    
    tipp_ellenorzes()
    
    
    #Megoldás ellenőrzése (győzelem/vereség?)
    
    
    if eletek <= 0:
        if vereseg():
            szo = szo_sorsolas()
            megoldas = len(szo) * "_"
            rossz_szavak = []
            rossz_tippek = []
            jo_tippek = []
            tipp = ""
            eletek = 12
            
        else:
            break
        
    elif megoldas == szo:
        if gyozelem():
            szo = szo_sorsolas()
            megoldas = len(szo) * "_"
            rossz_szavak = []
            rossz_tippek = []
            jo_tippek = []
            tipp = ""
            eletek = 12
            
        else:
            print(tiszta)
            break
        
    else:
        continue